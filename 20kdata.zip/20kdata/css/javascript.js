
        $(document).ready(function () {
            $('.songs').select2();
        });
        $('body').on('click', '.add-data', function (event) {
            event.preventDefault();
            var name = $('input[name=name]').val();
            var songs = $('.songs').val();
            $.ajax({
                method: 'POST',
                url: './database/db.php',
                data: {
                    name: name,
                    songs: songs,
                },
                success: function (data) {
                    console.log(data);
                    $('.res-msg').css('display', 'block');
                    $('.alert-success').text(data).show();
                    $('input[name=name]').val('');
                    $(".songs").val('').trigger('change');
                    setTimeout(function () {
                        $('.alert-success').hide();
                    }, 3500);

                }
            });
        });
