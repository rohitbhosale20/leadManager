<?php
include 'config.php';

## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value

                   


## Custom Field value Include
$searchByName = $_POST['searchByName'];
$searchByCompanyName = $_POST['searchByCompanyName'];
$searchByJobTitle = $_POST['searchByJobTitle'];
$searchByCountry = $_POST['searchByCountry'];
$searchByEmployeeSize = $_POST['searchByEmployeeSize'];
$searchByIndustry = $_POST['searchByIndustry'];
$searchByZipCode = $_POST['searchByZipCode'];

## Custom Field value exclude
          
$excludeByIndustry = $_POST['excludeByIndustry'];
$excludeByCountry = $_POST['excludeByCountry'];
$excludeByZipCode = $_POST['excludeByZipCode'];
$excludeByEmployeeSize = $_POST['excludeByEmployeeSize'];
$excludeByJobTitle = $_POST['excludeByJobTitle'];
$excludeByCompanyName = $_POST['excludeByCompanyName'];


## Search include

$searchQuery = " ";
if($searchByName != ''){
    $searchQuery .= " and (First_Name like '%".$searchByName."%') ";
}      
                                                                             

if($searchByCompanyName != ''){ $searchQuery .= " and (Company_Name like '%".$searchByCompanyName."%') ";
}

if($searchByJobTitle != ''){  $searchQuery .= " and (Job_Title like '%".$searchByJobTitle."%') ";
}

if($searchByCountry != ''){
    $searchQuery .= " and (Country  like '%".$searchByCountry."%') ";
}

if($searchByEmployeeSize != ''){
    $searchQuery .= " and (_Size  like '%".$searchByEmployeeSize."%') ";
}

if($searchByIndustry != ''){
    $searchQuery .= " and (Industry  like '%".$searchByIndustry."%') ";
}

if($searchByZipCode != ''){
    $searchQuery .= " and (Zip_Code  like '%".$searchByZipCode."%') ";
}

## Search exclude

if($excludeByIndustry != ''){
    $searchQuery .= " and (Industry NOT like '%".$excludeByIndustry."%') ";
}

if($excludeByCountry != ''){
    $searchQuery .= " and (Country NOT like '%".$excludeByCountry."%') ";
}

if($excludeByZipCode != ''){
    $searchQuery .= " and (Zip_Code NOT like '%".$excludeByZipCode."%') ";
}

if($excludeByEmployeeSize != ''){
    $searchQuery .= " and (_Size NOT  like '%".$excludeByEmployeeSize."%') ";
}

if($excludeByJobTitle != ''){
    $searchQuery .= " and (Job_Title NOT like '%".$excludeByJobTitle."%') ";
}

if($excludeByCompanyName != ''){
    $searchQuery .= " and (Company_Name NOT like '%".$excludeByCompanyName."%') ";
}


//comman search
if($searchValue != ''){
	$searchQuery .= " and (First_Name like '%".$searchValue."%' or 
    Last_Name like '%".$searchValue."%' or    
    Email_Address like '%".$searchValue."%' or 
    Company_Name like '%".$searchValue."%' or
    Company_Domain like '%".$searchValue."%' or
    Job_Title like '%".$searchValue."%' or
  
   

    Zip_Code like '%".$searchValue."%' or
    Country like '%".$searchValue."%' or
    _Size like '%".$searchValue."%' or
    
    Industry like '%".$searchValue."%')  ";
}

## Total number of records without filtering
$sel = mysqli_query($con,"select count(*) as allcount from 20lkh");
$records = mysqli_fetch_assoc($sel);
$totalRecords = $records['allcount'];

## Total number of records with filtering
$sel = mysqli_query($con,"select count(*) as allcount from 20lkh WHERE 1 ".$searchQuery);
$records = mysqli_fetch_assoc($sel);
$totalRecordwithFilter = $records['allcount'];

## Fetch records
$empQuery = "select * from 20lkh WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
$empRecords = mysqli_query($con, $empQuery);
$data = array();

while ($row = mysqli_fetch_assoc($empRecords)) {
    $data[] = array(
    		"First_Name"=>$row['First_Name'],
    		"Last_Name"=>$row['Last_Name'],
            "Email_Address"=>$row['Email_Address'],
    		"Company_Name"=>$row['Company_Name'],
    		"Company_Domain"=>$row['Company_Domain'],
    		"Job_Title"=>$row['Job_Title'],
        
            "Zip_Code"=>$row['Zip_Code'],
            "Country"=>$row['Country'],
         
            "_Size"=>$row['_Size'],
            "Industry"=>$row['Industry']
        );
}

## Response
$response = array(
    "draw" => intval($draw),
    "iTotalRecords" => $totalRecords,
    "iTotalDisplayRecords" => $totalRecordwithFilter,
    "aaData" => $data
);

echo json_encode($response);
